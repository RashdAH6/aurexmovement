// ════════════════════════════════════════════════
// SUPABASE CONFIG
// ════════════════════════════════════════════════
const SUPABASE_URL = 'https://udfpwakssijojlsuvqjm.supabase.co';
const SUPABASE_KEY = 'sb_publishable_pheGlJPG-oM5oPJqQAI1kQ_gYX7lnc_';
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Early function definitions (needed before DOM ready)
function toggleSettings(){
  const panel = document.getElementById('settingsPanel');
  if(panel) panel.classList.toggle('open');
}
function toggleAvatarMenu(){
  const d = document.getElementById('avatarDropdown');
  if(d) d.classList.toggle('open');
}
function closeAvatarMenu(){
  const d = document.getElementById('avatarDropdown');
  if(d) d.classList.remove('open');
}

// ════════════════════════════════════════════════
// STATE
// ════════════════════════════════════════════════
let currentUser = null;
let listings = [];
let favorites = [];
let currentView = 'home';
let previousView = 'home';
let currentDetailId = null;
let currentImgSlot = 0;
let slotImages = [null,null,null,null];
let slotFiles = [null,null,null,null];
let postAfterAuth = null;

// ════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════
async function init(){
  // Check Supabase auth session
  const { data: { session } } = await sb.auth.getSession();
  if(session){
    const meta = session.user.user_metadata;
    currentUser = {
      id: session.user.id,
      name: meta.name || session.user.email.split('@')[0],
      wa: meta.whatsapp || '',
      bio: meta.bio || '',
      email: session.user.email
    };
    localStorage.setItem('aurex_session', JSON.stringify(currentUser));
  } else {
    const saved = localStorage.getItem('aurex_session');
    if(saved) localStorage.removeItem('aurex_session');
    currentUser = null;
  }
  updateNavForUser();
  applyTheme(currentTheme);
  setLang(currentLang);
  await loadListings();
  await loadFavorites();
  renderHomeGrid();
  updateStatCount();
  // If opened via a shared #watch-{id} link, jump straight to it
  await handleHashRoute();
  window.scrollTo(0,0);

  // Listen for auth changes
  sb.auth.onAuthStateChange(async (event, session) => {
    if(session){
      const meta = session.user.user_metadata;
      currentUser = {
        id: session.user.id,
        name: meta.name || session.user.email.split('@')[0],
        wa: meta.whatsapp || '',
        bio: meta.bio || '',
        email: session.user.email
      };
      localStorage.setItem('aurex_session', JSON.stringify(currentUser));
    } else {
      currentUser = null;
      localStorage.removeItem('aurex_session');
    }
    await loadFavorites();
    updateNavForUser();
  });
}

let _listingsCacheTime = 0;
const LISTINGS_TTL = 60000; // 60 seconds

async function loadListings(force = false){
  const now = Date.now();
  if(!force && listings.length > 0 && (now - _listingsCacheTime) < LISTINGS_TTL) return;
  try {
    const { data, error } = await sb.from('listings').select('*').order('created_at', { ascending: false }).limit(500);
    if(error) throw error;
    listings = (data||[]).map(l=>({
      id: l.id,
      userId: l.user_id,
      userName: l.user_name,
      brand: l.brand,
      model: l.model,
      ref: l.ref_number,
      year: l.year,
      dial: l.dial_color,
      condition: l.condition,
      set: l.box_papers,
      desc: l.description,
      price: l.price,
      negotiable: l.negotiable ? 'yes' : 'no',
      wa: l.whatsapp,
      city: l.city,
      images: l.images || [],
      status: l.status,
      verified: l.seller_verified === true,
      createdAt: new Date(l.created_at).getTime(),
    }));
    _listingsCacheTime = now;
  } catch(e) {
    console.error('Supabase load error:', e);
    if(!listings.length) listings = JSON.parse(localStorage.getItem('aurex_listings_cache') || '[]');
  }
}

// ════════════════════════════════════════════════
// FAVORITES
// ════════════════════════════════════════════════
async function loadFavorites(){
  if(!currentUser){ favorites = []; return; }
  try {
    const { data, error } = await sb.from('favorites').select('listing_id').eq('user_id', currentUser.id);
    if(error) throw error;
    favorites = (data||[]).map(f=>f.listing_id);
  } catch(e){
    console.error('Favorites load error:', e);
    favorites = [];
  }
}

function isFavorited(id){ return favorites.includes(id); }

async function toggleFavorite(e, id){
  if(e){ e.stopPropagation(); }
  if(!currentUser){
    postAfterAuth = currentView;
    openModal('login');
    toast(currentLang==='ar'?'سجّل الدخول لحفظ المفضلة':'Log in to save favorites');
    return;
  }
  const fav = isFavorited(id);
  // Update local state + heart visuals immediately (optimistic)
  if(fav){ favorites = favorites.filter(f=>f!==id); }
  else if(!favorites.includes(id)){ favorites.push(id); }
  document.querySelectorAll(`[data-fav="${id}"]`).forEach(el=>{
    el.classList.toggle('active', isFavorited(id));
  });
  toast(fav
    ? (currentLang==='ar'?'أُزيلت من المفضلة':'Removed from favorites')
    : (currentLang==='ar'?'أُضيفت للمفضلة ♥':'Added to favorites ♥'));
  // Only the favorites page needs a re-render (item leaves the list)
  if(currentView==='favorites') renderFavorites();
  // Persist to Supabase
  try {
    if(fav){
      const { error } = await sb.from('favorites').delete().eq('user_id', currentUser.id).eq('listing_id', id);
      if(error) throw error;
    } else {
      const { error } = await sb.from('favorites').insert([{ user_id: currentUser.id, listing_id: id }]);
      if(error) throw error;
    }
  } catch(err){
    // Revert on failure
    if(fav){ if(!favorites.includes(id)) favorites.push(id); }
    else { favorites = favorites.filter(f=>f!==id); }
    document.querySelectorAll(`[data-fav="${id}"]`).forEach(el=>{
      el.classList.toggle('active', isFavorited(id));
    });
    if(currentView==='favorites') renderFavorites();
    toast('Error: '+err.message);
  }
}

function favBtnHtml(id){
  const active = isFavorited(id) ? ' active' : '';
  return `<button class="fav-btn${active}" data-fav="${id}" onclick="toggleFavorite(event,'${id}')" title="${currentLang==='ar'?'المفضلة':'Favorite'}">
    <svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
  </button>`;
}

function renderFavorites(){
  const container = document.getElementById('favoritesContent');
  if(!container) return;
  const L = T[currentLang];
  if(!currentUser){
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">🔒</div><p class="empty-text">${currentLang==='ar'?'يرجى تسجيل الدخول':'Please log in'}</p></div>`;
    return;
  }
  const favListings = listings.filter(l=>favorites.includes(l.id));
  if(favListings.length===0){
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">♡</div><p class="empty-text">${currentLang==='ar'?'لا توجد ساعات محفوظة':'No saved watches yet'}</p><p class="empty-sub">${currentLang==='ar'?'اضغط القلب على أي إعلان لحفظه هنا':'Tap the heart on any listing to save it here'}</p><button class="btn-primary" onclick="showView('listings')">${currentLang==='ar'?'تصفح السوق':'Browse Market'}</button></div>`;
    return;
  }
  container.innerHTML = `<div class="cards-grid" style="gap:1.5px;background:var(--border)">${favListings.map(l=>renderCard(l)).join('')}</div>`;
}

function updateStatCount(){
  const el = document.getElementById('statCount');
  if(!el) return;
  const target = listings.filter(l=>l.status==='available').length;
  let n=0; const step = Math.max(1,Math.ceil(target/30));
  const t = setInterval(()=>{ n=Math.min(n+step,target); el.textContent=n; if(n>=target)clearInterval(t); },40);
}

// ════════════════════════════════════════════════
// VIEWS
// ════════════════════════════════════════════════
async function showView(v){
  document.querySelectorAll('.view').forEach(el=>el.classList.remove('active'));
  const target = document.getElementById('view-'+v);
  if(!target) return;
  previousView = currentView;
  currentView = v;
  if(v!=='detail'){
    restoreMeta();
    if(location.hash.startsWith('#watch-')){
      try { history.pushState('', '', location.pathname); } catch(e){ location.hash=''; }
    }
  }
  target.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  if(v==='listings'){ await loadListings(); filterListings(); }
  if(v==='myads'){ await loadListings(); renderMyAds(); }
  if(v==='favorites'){ await loadListings(); await loadFavorites(); renderFavorites(); }
  if(v==='home'){ await loadListings(); renderHomeGrid(); updateStatCount(); }
  if(v==='post'){ resetPostForm(); }
  if(v==='profile'){ await loadListings(); loadProfile(); }
  if(v==='terms'){ renderTerms(); }
}

function goBack(){
  if(location.hash.startsWith('#watch-')){
    try { history.pushState('', '', location.pathname); } catch(e){ location.hash=''; }
  }
  restoreMeta();
  showView(previousView==='detail'?'listings':previousView);
}

function requireAuth(target){
  if(currentUser){ showView(target); }
  else{ postAfterAuth=target; openModal('register'); }
}

function filterByBrand(brand){
  showView('listings');
  setTimeout(()=>{
    document.getElementById('fBrand').value = brand;
    filterListings();
  },100);
}

// ════════════════════════════════════════════════
// AUTH
// ════════════════════════════════════════════════
function openModal(tab){
  document.getElementById('authModal').classList.add('open');
  switchTab(tab);
}
function closeModal(){
  document.getElementById('authModal').classList.remove('open');
  clearAuthError();
}
function switchTab(tab){
  document.getElementById('formLogin').style.display = tab==='login'?'block':'none';
  document.getElementById('formRegister').style.display = tab==='register'?'block':'none';
  document.getElementById('tabLogin').classList.toggle('active',tab==='login');
  document.getElementById('tabRegister').classList.toggle('active',tab==='register');
  clearAuthError();
}
function showAuthError(msg){ const e=document.getElementById('authError'); e.textContent=msg; e.classList.add('show'); }
function clearAuthError(){ document.getElementById('authError').classList.remove('show'); }

async function doRegister(){
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const wa = document.getElementById('regWA').value.trim().replace(/\D/g,'');
  const pass = document.getElementById('regPass').value;
  if(!name){ showAuthError(currentLang==='ar'?'يرجى إدخال الاسم':'Please enter your name'); return; }
  if(!email||!email.includes('@')){ showAuthError(currentLang==='ar'?'يرجى إدخال إيميل صحيح':'Please enter a valid email'); return; }
  if(wa.length < 7){ showAuthError(currentLang==='ar'?'يرجى إدخال رقم واتساب صحيح':'Please enter a valid WhatsApp number'); return; }
  if(pass.length < 6){ showAuthError(currentLang==='ar'?'كلمة المرور 6 أحرف على الأقل':'Password must be at least 6 characters'); return; }

  try {
    const {data, error} = await sb.auth.signUp({
      email, password: pass,
      options: { data: { name, whatsapp: wa } }
    });
    if(error) throw error;
    showAuthError(currentLang==='ar'
      ?'✅ تم التسجيل! تحقق من إيميلك لتأكيد الحساب'
      :'✅ Registered! Check your email to confirm your account');
    document.getElementById('authError').style.background='rgba(39,174,96,.12)';
    document.getElementById('authError').style.borderColor='rgba(39,174,96,.3)';
    document.getElementById('authError').style.color='#4ecb71';
  } catch(e){
    showAuthError(currentLang==='ar'?'خطأ: '+e.message:'Error: '+e.message);
  }
}

async function doLogin(){
  const email = document.getElementById('loginEmail').value.trim();
  const pass = document.getElementById('loginPass').value;
  if(!email){ showAuthError(currentLang==='ar'?'يرجى إدخال الإيميل':'Please enter your email'); return; }
  try {
    const {data, error} = await sb.auth.signInWithPassword({ email, password: pass });
    if(error) throw error;
    const user = data.user;
    const meta = user.user_metadata;
    loginUser({
      id: user.id,
      name: meta.name || email.split('@')[0],
      wa: meta.whatsapp || '',
      email: user.email
    });
  } catch(e){
    showAuthError(currentLang==='ar'?'إيميل أو كلمة مرور غير صحيحة':'Incorrect email or password');
  }
}

async function doForgotPassword(){
  const email = document.getElementById('loginEmail').value.trim();
  if(!email){ showAuthError(currentLang==='ar'?'أدخل إيميلك أولاً':'Enter your email first'); return; }
  try {
    await sb.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.href
    });
    showAuthError(currentLang==='ar'
      ?'✅ تم إرسال رابط إعادة تعيين كلمة المرور على إيميلك'
      :'✅ Password reset link sent to your email');
    document.getElementById('authError').style.background='rgba(39,174,96,.12)';
    document.getElementById('authError').style.borderColor='rgba(39,174,96,.3)';
    document.getElementById('authError').style.color='#4ecb71';
  } catch(e){
    showAuthError('Error: '+e.message);
  }
}

function loginUser(user){
  currentUser = user;
  localStorage.setItem('aurex_session', JSON.stringify(user));
  updateNavForUser();
  closeModal();
  toast((currentLang==='ar'?'أهلاً ':'Welcome ')+user.name+' 👋');
  if(postAfterAuth){ showView(postAfterAuth); postAfterAuth=null; }
}

function updateNavForUser(){
  const g = document.getElementById('navGuest');
  const u = document.getElementById('navUser');
  const a = document.getElementById('navAvatar');
  const dn = document.getElementById('dropdownName');
  const dw = document.getElementById('dropdownWa');
  if(currentUser){
    g.style.display='none'; u.style.display='flex';
    a.textContent = currentUser.name.charAt(0).toUpperCase();
    if(dn) dn.textContent = currentUser.name;
    if(dw) dw.textContent = '+971 '+currentUser.wa;
  } else {
    g.style.display='flex'; u.style.display='none';
    if(a) a.textContent='؟';
  }
}

async function logout(){
  if(!confirm(currentLang==='ar'?'تسجيل الخروج؟':'Log out?')) return;
  await sb.auth.signOut();
  currentUser = null;
  localStorage.removeItem('aurex_session');
  updateNavForUser();
  showView('home');
  toast(currentLang==='ar'?'تم تسجيل الخروج':'Logged out');
}

// ════════════════════════════════════════════════
// LISTINGS RENDER
// ════════════════════════════════════════════════
function renderCard(l, mini=false){
  const L = T[currentLang];
  const locale = currentLang==='ar'?'ar-AE':'en-AE';
  const imgHtml = l.images && l.images[0]
    ? `<img src="${l.images[0]}" alt="${l.brand} ${l.model}">`
    : `<div class="placeholder-svg"><svg viewBox="0 0 80 80" fill="none" stroke="rgba(201,161,91,0.5)" stroke-width="1"><circle cx="40" cy="40" r="28"/><circle cx="40" cy="40" r="20"/><line x1="40" y1="20" x2="40" y2="25"/><line x1="40" y1="55" x2="40" y2="60"/><line x1="20" y1="40" x2="25" y2="40"/><line x1="55" y1="40" x2="60" y2="40"/><line x1="40" y1="40" x2="40" y2="30"/><line x1="40" y1="40" x2="48" y2="43"/></svg></div>`;
  const badge = l.status==='available'
    ? `<span class="wcard-badge badge-available">${L.available}</span>`
    : `<span class="wcard-badge badge-sold">${L.sold}</span>`;
  const isNew = (Date.now()-l.createdAt)<86400000 && l.status==='available'
    ? `<span class="wcard-featured">${L.newBadge}</span>` : '';
  const priceDisplay = l.price ? Number(l.price).toLocaleString(locale)+' AED' : (currentLang==='ar'?'تفاوضي':'Negotiable');
  const cityHtml = l.city ? `<div class="wcard-location"><svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>${l.city}</div>` : '';

  return `
  <div class="wcard" onclick="openDetail('${l.id}')">
    <div class="wcard-img">${isNew}${badge}${favBtnHtml(l.id)}${imgHtml}</div>
    <div class="wcard-body">
      <div class="wcard-brand">${l.brand}${l.verified?` <span class="verified-mini" title="${currentLang==='ar'?'تاجر موثق':'Verified'}"><svg viewBox="0 0 24 24" width="11" height="11" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></span>`:''}</div>
      <div class="wcard-model">${l.model}</div>
      <div class="wcard-meta">
        <div class="wcard-meta-item"><label>${L.condLabel}</label><span>${l.condition||'—'}</span></div>
        <div class="wcard-meta-item"><label>${currentLang==='ar'?'البوكس':'Box'}</label><span>${l.set?l.set.split(' ')[0]:'—'}</span></div>
        ${l.ref?`<div class="wcard-meta-item"><label>Ref.</label><span>${l.ref}</span></div>`:''}
        ${l.year?`<div class="wcard-meta-item"><label>${currentLang==='ar'?'السنة':'Year'}</label><span>${l.year}</span></div>`:''}
      </div>
    </div>
    <div class="wcard-footer">
      <div>
        <div class="wcard-price ${l.negotiable==='yes'?'negotiable':''}">${priceDisplay}</div>
        ${cityHtml}
      </div>
      ${l.status==='available'?`<button class="wcard-wa" onclick="event.stopPropagation();openDetail('${l.id}')">
        <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.12.554 4.112 1.523 5.843L0 24l6.335-1.505A11.95 11.95 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818c-1.89 0-3.658-.51-5.172-1.397l-.371-.22-3.761.894.938-3.664-.242-.384A9.8 9.8 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
        ${L.whatsapp}
      </button>`:''}
    </div>
  </div>`;
}

function renderHomeGrid(){
  const grid = document.getElementById('homeGrid');
  const empty = document.getElementById('homeEmpty');
  if(!grid) return;
  const recent = [...listings].filter(l=>l.status==='available').sort((a,b)=>b.createdAt-a.createdAt).slice(0,6);
  if(recent.length===0){ grid.style.display='none'; empty.style.display='block'; }
  else { grid.style.display='grid'; empty.style.display='none'; grid.innerHTML=recent.map(l=>renderCard(l)).join(''); }
}

function filterListings(){
  const brand = document.getElementById('fBrand')?.value||'';
  const cond = document.getElementById('fCond')?.value||'';
  const set = document.getElementById('fSet')?.value||'';
  const pMin = parseFloat(document.getElementById('fPriceMin')?.value||0)||0;
  const pMax = parseFloat(document.getElementById('fPriceMax')?.value||0)||Infinity;
  const sort = document.getElementById('sortSel')?.value||'newest';
  const search = document.getElementById('globalSearch')?.value?.toLowerCase()||'';

  let results = listings.filter(l=>{
    if(brand && l.brand!==brand) return false;
    if(cond && l.condition!==cond) return false;
    if(set && !l.set?.includes(set)) return false;
    if(l.price && pMin>0 && Number(l.price)<pMin) return false;
    if(l.price && pMax<Infinity && Number(l.price)>pMax) return false;
    if(search){
      const hay = (l.brand+' '+l.model+' '+l.ref+' '+l.desc).toLowerCase();
      if(!hay.includes(search)) return false;
    }
    return true;
  });

  if(sort==='price_asc') results.sort((a,b)=>Number(a.price||0)-Number(b.price||0));
  else if(sort==='price_desc') results.sort((a,b)=>Number(b.price||0)-Number(a.price||0));
  else results.sort((a,b)=>b.createdAt-a.createdAt);

  const grid = document.getElementById('listingsGrid');
  const empty = document.getElementById('listingsEmpty');
  const count = document.getElementById('resultsCount');
  if(!grid) return;

  document.getElementById('listingsCount').textContent = listings.length===0
    ?(currentLang==='ar'?'لا توجد إعلانات':'No listings')
    :results.length+' '+(currentLang==='ar'?'إعلان':'Listing'+(results.length!==1?'s':''));
  count.textContent = results.length+' '+(currentLang==='ar'?'نتيجة':'Result'+(results.length!==1?'s':''));

  if(results.length===0){ grid.style.display='none'; empty.style.display='block'; }
  else { grid.style.display='grid'; empty.style.display='none'; grid.innerHTML=results.map(l=>renderCard(l)).join(''); }
}

function handleSearch(val){
  if(currentView==='listings') filterListings();
}

function resetFilters(){
  ['fBrand','fCond','fSet'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  ['fPriceMin','fPriceMax'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  filterListings();
}

function setView(mode){
  const grid = document.getElementById('listingsGrid');
  document.getElementById('gridBtn').classList.toggle('active',mode==='grid');
  document.getElementById('listBtn').classList.toggle('active',mode==='list');
  grid.classList.toggle('list-view',mode==='list');
}

// ════════════════════════════════════════════════
// DETAIL
// ════════════════════════════════════════════════
function openDetail(id, skipHash){
  const l = listings.find(l=>l.id===id);
  if(!l) return;
  currentDetailId = id;
  if(!skipHash){
    try { history.pushState({watch:id}, '', '#watch-'+id); } catch(e){ location.hash = 'watch-'+id; }
  }
  // SEO: reflect the watch in the page title + description
  try {
    const parts = [l.brand, l.model, l.ref].filter(Boolean).join(' ');
    document.title = `${parts} | Aurex Movement`;
    const md = document.querySelector('meta[name="description"]');
    if(md){
      if(!window._defaultMetaDesc) window._defaultMetaDesc = md.getAttribute('content');
      const priceTxt = l.price ? Number(l.price).toLocaleString('en-AE')+' AED' : 'Negotiable';
      md.setAttribute('content', `${l.brand} ${l.model}${l.ref?' (Ref. '+l.ref+')':''} — ${priceTxt}. ${l.city||'UAE'}. Aurex Movement luxury watch marketplace.`);
    }
  } catch(e){}
  showView('detail');
  const L = T[currentLang];
  const locale = currentLang==='ar'?'ar-AE':'en-AE';
  const waNum = '971'+l.wa.replace(/\D/g,'');
  const waMsg = encodeURIComponent(currentLang==='ar'
    ?'مرحباً، رأيت إعلانك على Aurex Movement بخصوص '+l.brand+' '+l.model+'. هل لا تزال متاحة؟'
    :'Hi, I saw your listing on Aurex Movement for the '+l.brand+' '+l.model+'. Is it still available?');
  const priceDisplay = l.price ? Number(l.price).toLocaleString(locale)+' AED' : (currentLang==='ar'?'تفاوضي':'Negotiable');
  const seller = l.userName
    ? {name:l.userName, wa:l.wa}
    : {name:currentLang==='ar'?'بائع':'Seller', wa:l.wa};
  const mainImg = l.images&&l.images[0]
    ? `<img src="${l.images[0]}" alt="${l.brand}">`
    : `<div class="big-placeholder"><svg viewBox="0 0 80 80"><circle cx="40" cy="40" r="28"/><circle cx="40" cy="40" r="20"/><line x1="40" y1="20" x2="40" y2="25"/><line x1="40" y1="55" x2="40" y2="60"/><line x1="20" y1="40" x2="25" y2="40"/><line x1="55" y1="40" x2="60" y2="40"/><line x1="40" y1="40" x2="40" y2="30"/><line x1="40" y1="40" x2="48" y2="43"/></svg></div>`;
  const thumbs = (l.images||[]).map((img,i)=>`<div class="detail-thumb ${i===0?'active':''}" onclick="swapImg(this,'${img}')"><img src="${img}"></div>`).join('');

  document.getElementById('detailContent').innerHTML = `
    <div class="detail-imgs">
      <div class="detail-main-img" id="detailMainImg">${mainImg}</div>
      ${thumbs?`<div class="detail-thumbs">${thumbs}</div>`:''}
    </div>
    <div class="detail-info">
      <div class="detail-brand">${l.brand}</div>
      <h1 class="detail-model">${l.model}</h1>
      <p class="detail-sub">${[l.ref,l.year,l.dial].filter(Boolean).join(' · ')}</p>
      <div class="detail-price-box">
        <div class="detail-price-label">${currentLang==='ar'?'السعر':'Price'}</div>
        <div class="detail-price">${priceDisplay}</div>
        ${l.negotiable==='yes'?`<div class="detail-price-neg">${L.priceNeg}</div>`:''}
      </div>
      <div class="detail-seller">
        <div class="seller-avatar">${seller.name.charAt(0)}</div>
        <div><div class="seller-name">${seller.name}${l.verified?` <span class="verified-badge" title="${currentLang==='ar'?'تاجر موثق':'Verified Seller'}"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></span>`:''}</div><div class="seller-since">${l.verified?(currentLang==='ar'?'تاجر موثق':'Verified Seller'):L.sellerLabel} · ${l.city||'UAE'}</div></div>
      </div>
      ${l.status==='available'?`
      <div id="contactReveal" class="contact-reveal">
        <button class="detail-cta-reveal" onclick="revealContact('${l.id}')">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          ${currentLang==='ar'?'إظهار رقم التواصل':'Show Contact Number'}
        </button>
      </div>
      `:`<div style="background:rgba(167,167,167,.08);border:1px solid rgba(167,167,167,.15);padding:1rem;text-align:center;font-size:.8rem;color:var(--grey)">${currentLang==='ar'?'هذه الساعة مُباعة':'This watch has been sold'}</div>`}
      <button class="detail-cta-share" onclick="shareListing('${l.id}')">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
        ${currentLang==='ar'?'مشاركة الإعلان':'Share Listing'}
      </button>
      <div class="detail-specs">
        <h3 class="detail-specs-title">${currentLang==='ar'?'مواصفات الساعة':'Watch Specifications'}</h3>
        <div class="specs-grid">
          <div class="spec-item"><div class="spec-label">${L.specsBrand}</div><div class="spec-val">${l.brand}</div></div>
          <div class="spec-item"><div class="spec-label">${L.specsModel}</div><div class="spec-val">${l.model}</div></div>
          ${l.ref?`<div class="spec-item"><div class="spec-label">${L.specsRef}</div><div class="spec-val">${l.ref}</div></div>`:''}
          ${l.year?`<div class="spec-item"><div class="spec-label">${L.specsYear}</div><div class="spec-val">${l.year}</div></div>`:''}
          ${l.condition?`<div class="spec-item"><div class="spec-label">${L.specsCond}</div><div class="spec-val">${l.condition}</div></div>`:''}
          ${l.set?`<div class="spec-item"><div class="spec-label">${L.specsSet}</div><div class="spec-val">${l.set}</div></div>`:''}
          ${l.dial?`<div class="spec-item"><div class="spec-label">${L.specsDial}</div><div class="spec-val">${l.dial}</div></div>`:''}
          ${l.city?`<div class="spec-item"><div class="spec-label">${L.specsCity}</div><div class="spec-val">${l.city}</div></div>`:''}
        </div>
      </div>
      ${l.desc?`<div class="detail-desc"><h3 class="detail-desc-title">${currentLang==='ar'?'وصف البائع':'Seller Description'}</h3><p>${l.desc}</p></div>`:''}
    </div>
  `;
}

function revealContact(id){
  const l = listings.find(l=>l.id===id);
  if(!l) return;
  const box = document.getElementById('contactReveal');
  if(!box) return;
  const waNum = '971' + l.wa.replace(/\D/g,'');
  const waMsg = encodeURIComponent(currentLang==='ar'
    ?'مرحباً، رأيت إعلانك على Aurex Movement بخصوص '+l.brand+' '+l.model+'. هل لا تزال متاحة؟'
    :'Hi, I saw your listing on Aurex Movement for the '+l.brand+' '+l.model+'. Is it still available?');
  const L = T[currentLang];
  box.innerHTML = `
    <a class="detail-cta-wa" href="https://wa.me/${waNum}?text=${waMsg}" target="_blank" rel="nofollow noopener">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.12.554 4.112 1.523 5.843L0 24l6.335-1.505A11.95 11.95 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818c-1.89 0-3.658-.51-5.172-1.397l-.371-.22-3.761.894.938-3.664-.242-.384A9.8 9.8 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
      ${L.contactWa}
    </a>
    <a class="detail-cta-call" href="tel:+${waNum}" rel="nofollow">📞 +971 ${l.wa}</a>`;
}

async function shareListing(id){
  const l = listings.find(l=>l.id===id);
  if(!l) return;
  const url = 'https://aurexmovement.com/watch/'+id;
  const price = l.price ? Number(l.price).toLocaleString(currentLang==='ar'?'ar-AE':'en-AE')+' AED' : (currentLang==='ar'?'السعر تفاوضي':'Negotiable');
  const title = `${l.brand} ${l.model}`;
  const text = currentLang==='ar'
    ? `شاهد هذه الساعة على Aurex Movement:\n${l.brand} ${l.model} — ${price}`
    : `Check out this watch on Aurex Movement:\n${l.brand} ${l.model} — ${price}`;
  // Native share (mobile) if available
  if(navigator.share){
    try {
      await navigator.share({ title, text, url });
      return;
    } catch(e){
      if(e && e.name==='AbortError') return; // user cancelled
    }
  }
  // Fallback: copy link to clipboard
  try {
    await navigator.clipboard.writeText(url);
    toast(currentLang==='ar'?'تم نسخ رابط الإعلان ✦':'Listing link copied ✦');
  } catch(e){
    // Last resort: temporary input + execCommand
    const tmp = document.createElement('input');
    tmp.value = url; document.body.appendChild(tmp); tmp.select();
    try { document.execCommand('copy'); toast(currentLang==='ar'?'تم نسخ الرابط':'Link copied'); }
    catch(_){ toast(url); }
    document.body.removeChild(tmp);
  }
}

// Open a listing directly if the URL contains #watch-{id}
async function handleHashRoute(){
  const h = location.hash || '';
  const m = h.match(/^#watch-(.+)$/);
  if(m){
    const id = m[1];
    if(!listings.length) await loadListings();
    const l = listings.find(l=>l.id===id);
    if(l){ openDetail(id, true); return true; }
  }
  return false;
}

function restoreMeta(){
  try {
    document.title = 'Aurex Movement | سوق الساعات الفاخرة في الإمارات والخليج | Luxury Watches UAE';
    const md = document.querySelector('meta[name="description"]');
    if(md && window._defaultMetaDesc) md.setAttribute('content', window._defaultMetaDesc);
  } catch(e){}
}

function swapImg(el, src){
  document.querySelectorAll('.detail-thumb').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('detailMainImg').innerHTML=`<img src="${src}" alt="watch">`;
}

// ════════════════════════════════════════════════
// POST LISTING
// ════════════════════════════════════════════════
function resetPostForm(){
  slotImages=[null,null,null,null];
  slotFiles=[null,null,null,null];
  ['pBrand','pModel','pRef','pYear','pDial','pCond','pSet','pDesc','pPrice','pWA','pCity'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.value='';
  });
  document.getElementById('pNeg').value='no';
  document.getElementById('pTerms').checked=false;
  document.getElementById('postPreview').classList.remove('show');
  document.getElementById('successBox').classList.remove('show');
  document.getElementById('postFormWrap').style.display='block';
  renderImgSlots();
}

function renderImgSlots(){
  const mainLbl = currentLang==='ar'?'الصورة الرئيسية':'Main Photo';
  const addLbl = currentLang==='ar'?'إضافة':'Add';
  for(let i=0;i<4;i++){
    const slot=document.getElementById('slot'+i);
    if(!slot) continue;
    if(slotImages[i]){
      slot.innerHTML=`<img src="${slotImages[i]}"><div class="img-del" onclick="delImg(event,${i})">✕</div>`;
    } else {
      if(i===0) slot.innerHTML=`<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="var(--grey)" stroke-width="1.5"><path d="M21 19V5a2 2 0 00-2-2H5a2 2 0 00-2 2v14l4-4 3 3 4-5z"/><circle cx="8.5" cy="8.5" r="1.5"/></svg><span>${mainLbl}</span>`;
      else slot.innerHTML=`<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--grey)" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>${addLbl}</span>`;
    }
  }
}

function triggerImg(slot){ currentImgSlot=slot; document.getElementById('imgInput').click(); }

function handleImg(input){
  const file = input.files[0]; if(!file) return;
  slotFiles[currentImgSlot]=file;
  const reader=new FileReader();
  reader.onload=e=>{
    slotImages[currentImgSlot]=e.target.result;
    renderImgSlots();
    updatePreview();
  };
  reader.readAsDataURL(file);
  input.value='';
}

function delImg(e,i){ e.stopPropagation(); slotImages[i]=null; slotFiles[i]=null; renderImgSlots(); updatePreview(); }

async function uploadImages(){
  const urls = [];
  for(let i=0;i<4;i++){
    const file = slotFiles[i];
    if(file){
      try {
        const ext = (file.name.split('.').pop()||'jpg').toLowerCase();
        const path = `${currentUser.id}/${Date.now()}_${i}.${ext}`;
        const { error } = await sb.storage.from('listing-images')
          .upload(path, file, { contentType:file.type, upsert:false });
        if(error) throw error;
        const { data } = sb.storage.from('listing-images').getPublicUrl(path);
        urls.push(data.publicUrl);
      } catch(err){
        console.warn('Storage upload failed, using inline image:', err);
        if(slotImages[i]) urls.push(slotImages[i]);
      }
    } else if(slotImages[i]){
      urls.push(slotImages[i]);
    }
  }
  return urls;
}

function updatePreview(){
  const brand=document.getElementById('pBrand').value;
  const model=document.getElementById('pModel').value;
  const price=document.getElementById('pPrice').value;
  if(!brand&&!model) return;
  document.getElementById('postPreview').classList.add('show');
  document.getElementById('previewBrand').textContent=brand||'—';
  document.getElementById('previewModel').textContent=model||'—';
  document.getElementById('previewPrice').textContent=price?Number(price).toLocaleString('ar-AE')+' AED':'—';
  const pi=document.getElementById('previewImg');
  if(slotImages[0]) pi.innerHTML=`<img src="${slotImages[0]}" style="width:100%;height:100%;object-fit:cover">`;
}

async function submitListing(){
  const brand=document.getElementById('pBrand').value;
  const model=document.getElementById('pModel').value;
  const cond=document.getElementById('pCond').value;
  const price=document.getElementById('pPrice').value;
  const wa=document.getElementById('pWA').value.trim().replace(/\D/g,'');
  const terms=document.getElementById('pTerms').checked;

  if(!brand){ toast(currentLang==='ar'?'يرجى اختيار الماركة':'Please select a brand'); return; }
  if(!model){ toast(currentLang==='ar'?'يرجى إدخال الموديل':'Please enter the model'); return; }
  if(!wa||wa.length<7){ toast(currentLang==='ar'?'يرجى إدخال رقم الواتساب':'Please enter your WhatsApp number'); return; }
  if(!terms){ toast(currentLang==='ar'?'يرجى الموافقة على الشروط':'Please agree to the terms'); return; }

  const btn=document.getElementById('publishBtnEl');
  btn.textContent=currentLang==='ar'?'جاري النشر...':'Publishing...';
  btn.disabled=true;

  try {
    const imageUrls = await uploadImages();
    const {error} = await sb.from('listings').insert([{
      user_id: String(currentUser.id),
      user_name: currentUser.name,
      brand, model,
      ref_number: document.getElementById('pRef').value.trim(),
      year: document.getElementById('pYear').value.trim(),
      dial_color: document.getElementById('pDial').value.trim(),
      condition: cond,
      box_papers: document.getElementById('pSet').value,
      description: document.getElementById('pDesc').value.trim(),
      price: price||null,
      negotiable: document.getElementById('pNeg').value==='yes',
      whatsapp: wa,
      city: document.getElementById('pCity').value,
      images: imageUrls,
      status: 'available',
    }]);
    if(error) throw error;

    document.getElementById('postFormWrap').style.display='none';
    document.getElementById('successBox').classList.add('show');
    toast(currentLang==='ar'?'نُشر إعلانك بنجاح! ✦':'Listing published! ✦');
    await loadListings(true); renderHomeGrid(); updateStatCount();
  } catch(e){
    console.error(e);
    toast(currentLang==='ar'?'خطأ: '+e.message:'Error: '+e.message);
    btn.textContent=T[currentLang].publishBtn;
    btn.disabled=false;
  }
}

// ════════════════════════════════════════════════
// MY ADS
// ════════════════════════════════════════════════
function renderMyAds(){
  const container=document.getElementById('myAdsContent');
  const L=T[currentLang];
  if(!currentUser){ container.innerHTML=`<div class="empty-state"><div class="empty-icon">🔒</div><p class="empty-text">${currentLang==='ar'?'يرجى تسجيل الدخول':'Please log in'}</p></div>`; return; }
  const myListings=listings.filter(l=>l.userId===currentUser.id);
  if(myListings.length===0){
    container.innerHTML=`<div class="empty-state"><div class="empty-icon">⌚</div><p class="empty-text">${L.emptyMyAds}</p><p class="empty-sub">${L.emptyMyAdsSub}</p><button class="btn-primary" onclick="showView('post')">${L.addFirst}</button></div>`;
    return;
  }
  const locale = currentLang==='ar'?'ar-AE':'en-AE';
  container.innerHTML=myListings.map(l=>{
    const priceDisplay=l.price?Number(l.price).toLocaleString(locale)+' AED':(currentLang==='ar'?'تفاوضي':'Negotiable');
    const imgHtml=l.images&&l.images[0]?`<img src="${l.images[0]}">`:`<div class="ph"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/></svg></div>`;
    const statusLabel = l.status==='available'?(currentLang==='ar'?'نشط':'Active'):(currentLang==='ar'?'مُباع':'Sold');
    return `<div class="myad-card">
      <div class="myad-img">${imgHtml}</div>
      <div class="myad-body">
        <div class="myad-brand">${l.brand}</div>
        <div class="myad-model">${l.model}</div>
        <div class="myad-meta">${l.condition||''} ${l.set?'· '+l.set:''} ${l.city?'· '+l.city:''}</div>
        <div style="margin-top:.5rem;font-size:.65rem;color:rgba(167,167,167,.4)">${new Date(l.createdAt).toLocaleDateString(locale)}</div>
      </div>
      <div class="myad-actions">
        <div>
          <div class="myad-status ${l.status==='available'?'status-live':'status-sold-lbl'}">${statusLabel}</div>
          <div class="myad-price">${priceDisplay}</div>
        </div>
        <div class="myad-btns">
          ${l.status==='available'
            ?`<button class="myad-btn" onclick="markSold('${l.id}')">${L.markSoldBtn}</button>`
            :`<button class="myad-btn" onclick="relistListing('${l.id}')">${L.relistBtn}</button>`}
          <button class="myad-btn del" onclick="deleteListing('${l.id}')">${L.deleteBtn}</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

async function markSold(id){
  const l=listings.find(l=>l.id===id);
  if(!l || l.userId !== currentUser?.id){ toast(currentLang==='ar'?'غير مصرح':'Not authorized'); return; }
  try {
    await sb.from('listings').update({status:'sold'}).eq('id',id).eq('user_id',currentUser.id);
    await loadListings(true); renderMyAds();
    toast(currentLang==='ar'?'تم تحديث الإعلان كمُباع':'Listing marked as sold');
  } catch(e){ toast('Error: '+e.message); }
}

async function relistListing(id){
  const l=listings.find(l=>l.id===id);
  if(!l || l.userId !== currentUser?.id){ toast(currentLang==='ar'?'غير مصرح':'Not authorized'); return; }
  try {
    await sb.from('listings').update({status:'available'}).eq('id',id).eq('user_id',currentUser.id);
    await loadListings(true); renderMyAds(); updateStatCount(); renderHomeGrid();
    toast(currentLang==='ar'?'تم إعادة نشر الإعلان':'Listing is live again');
  } catch(e){ toast('Error: '+e.message); }
}

async function deleteListing(id){
  const l=listings.find(l=>l.id===id);
  if(!l || l.userId !== currentUser?.id){ toast(currentLang==='ar'?'غير مصرح':'Not authorized'); return; }
  if(!confirm(currentLang==='ar'?'هل تريد حذف هذا الإعلان؟':'Delete this listing?')) return;
  try {
    await sb.from('listings').delete().eq('id',id).eq('user_id',currentUser.id);
    await loadListings(true); renderMyAds(); updateStatCount(); renderHomeGrid();
    toast(currentLang==='ar'?'تم حذف الإعلان':'Listing deleted');
  } catch(e){ toast('Error: '+e.message); }
}

// ════════════════════════════════════════════════
// TOAST
// ════════════════════════════════════════════════
function toast(msg){
  const t=document.getElementById('toast');
  t.textContent=msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),3000);
}

// ════════════════════════════════════════════════
// PROFILE
// ════════════════════════════════════════════════
async function loadProfile(){
  if(!currentUser) return;
  const L = T[currentLang];

  // Prefer Supabase metadata, fall back to localStorage cache
  const saved = JSON.parse(localStorage.getItem('aurex_profile_'+currentUser.id)||'{}');
  const bio = currentUser.bio || saved.bio || '';
  const wa = currentUser.wa || saved.wa || '';
  const name = currentUser.name || saved.name || '';

  // Update avatar
  const av = document.getElementById('profileAvatar');
  if(av) av.textContent = name.charAt(0).toUpperCase();

  // Update display
  safeText('profileName', name);
  safeText('profileWa', wa ? '+971 '+wa : '');
  safeText('profileBio', bio);

  // Count ads
  const myAds = listings.filter(l=>l.userId===currentUser.id);
  safeText('profileAdsCount', myAds.length.toString());
  safeText('profileAdsLabel', currentLang==='ar'?'إعلان':'Listing');

  // Fill edit form
  const en = document.getElementById('editName'); if(en) en.value = name;
  const eb = document.getElementById('editBio'); if(eb) eb.value = bio;
  const ew = document.getElementById('editWa'); if(ew) ew.value = wa;

  // Translate labels
  safeText('editProfileTitle', currentLang==='ar'?'تعديل الملف الشخصي':'Edit Profile');
  safeText('profileNameLabel', currentLang==='ar'?'الاسم':'Name');
  safeText('profileBioLabel', currentLang==='ar'?'البايو':'Bio');
  safeText('profileWaLabel', currentLang==='ar'?'رقم الواتساب':'WhatsApp Number');
  safeText('saveProfileBtn', currentLang==='ar'?'حفظ التغييرات':'Save Changes');
  safeText('changePassTitle', currentLang==='ar'?'تغيير كلمة المرور':'Change Password');
  safeText('newPassLabel', currentLang==='ar'?'كلمة المرور الجديدة':'New Password');
  safeText('changePassBtn', currentLang==='ar'?'تغيير كلمة المرور':'Change Password');
  safeText('profileMyAdsTitle', currentLang==='ar'?'إعلاناتي':'My Listings');
  safeText('profileBackBtn', currentLang==='ar'?'العودة':'Back');

  const bio_ph = document.getElementById('editBio');
  if(bio_ph) bio_ph.placeholder = currentLang==='ar'?'أخبر الناس عنك...':'Tell people about yourself...';

  // Render my ads
  const container = document.getElementById('profileMyAds');
  if(!container) return;
  if(myAds.length===0){
    container.innerHTML=`<div style="text-align:center;padding:2rem;color:var(--grey)"><div style="font-size:2rem;opacity:.2;margin-bottom:.5rem">⌚</div><p style="font-size:.85rem">${currentLang==='ar'?'لا توجد إعلانات بعد':'No listings yet'}</p></div>`;
  } else {
    container.innerHTML = myAds.map(l=>{
      const locale = currentLang==='ar'?'ar-AE':'en-AE';
      const price = l.price?Number(l.price).toLocaleString(locale)+' AED':(currentLang==='ar'?'تفاوضي':'Negotiable');
      const img = l.images&&l.images[0]?`<img src="${l.images[0]}" style="width:60px;height:60px;object-fit:cover">`:`<div style="width:60px;height:60px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:1.2rem;opacity:.3">⌚</div>`;
      const statusLabel = l.status==='available'?(currentLang==='ar'?'نشط':'Active'):(currentLang==='ar'?'مُباع':'Sold');
      const statusColor = l.status==='available'?'var(--gold)':'var(--grey)';
      return `<div style="display:flex;align-items:center;gap:1rem;padding:1rem 0;border-bottom:1px solid var(--border2);cursor:pointer" onclick="openDetail('${l.id}')">
        ${img}
        <div style="flex:1">
          <div style="font-size:.58rem;letter-spacing:.2em;text-transform:uppercase;color:var(--gold)">${l.brand}</div>
          <div style="font-family:var(--serif);font-size:1rem;color:var(--white)">${l.model}</div>
          <div style="font-size:.75rem;color:var(--grey)">${price}</div>
        </div>
        <div style="font-size:.6rem;letter-spacing:.12em;text-transform:uppercase;color:${statusColor}">${statusLabel}</div>
      </div>`;
    }).join('');
  }
}

async function saveProfile(){
  if(!currentUser) return;
  const name = document.getElementById('editName').value.trim();
  const bio = document.getElementById('editBio').value.trim();
  const wa = document.getElementById('editWa').value.trim().replace(/\D/g,'');

  if(!name){ toast(currentLang==='ar'?'يرجى إدخال الاسم':'Please enter your name'); return; }

  const btn = document.getElementById('saveProfileBtn');
  if(btn){ btn.disabled = true; btn.textContent = currentLang==='ar'?'جاري الحفظ...':'Saving...'; }

  try {
    // Persist to Supabase auth metadata
    const { error } = await sb.auth.updateUser({ data: { name, whatsapp: wa, bio } });
    if(error) throw error;
  } catch(e){
    toast('Error: '+e.message);
    if(btn){ btn.disabled = false; btn.textContent = currentLang==='ar'?'حفظ التغييرات':'Save Changes'; }
    return;
  }

  // Save to localStorage (for bio which isn't in auth metadata)
  localStorage.setItem('aurex_profile_'+currentUser.id, JSON.stringify({ name, bio, wa }));

  // Update currentUser in memory + session
  currentUser.name = name;
  currentUser.wa = wa;
  currentUser.bio = bio;
  localStorage.setItem('aurex_session', JSON.stringify(currentUser));
  updateNavForUser();

  if(btn){ btn.disabled = false; btn.textContent = currentLang==='ar'?'حفظ التغييرات':'Save Changes'; }
  loadProfile();
  toast(currentLang==='ar'?'تم حفظ التغييرات ✦':'Changes saved ✦');
}

async function changePassword(){
  const newPass = document.getElementById('newPass').value;
  if(newPass.length < 6){ toast(currentLang==='ar'?'كلمة المرور 6 أحرف على الأقل':'Password must be at least 6 characters'); return; }
  try {
    const {error} = await sb.auth.updateUser({ password: newPass });
    if(error) throw error;
    document.getElementById('newPass').value = '';
    toast(currentLang==='ar'?'تم تغيير كلمة المرور ✦':'Password changed ✦');
  } catch(e){
    toast('Error: '+e.message);
  }
}

// ════════════════════════════════════════════════
// SETTINGS — THEME & LANGUAGE
// ════════════════════════════════════════════════
const T = {
  ar:{
    siteName:'Aurex Movement',
    heroBadge:'UAE & GCC · سوق الساعات الفاخرة',
    heroH1:'سوق <em>الساعات</em><br>الفاخرة',
    heroSub:'منصة حصرية لبيع وشراء الساعات الفاخرة الأصيلة في الإمارات والخليج',
    heroDivider:'بيع · شراء · تواصل مباشر',
    heroBrowse:'تصفح الإعلانات',
    heroPost:'+ أضف إعلانك',
    statLabel:'إعلان نشط',
    navMarket:'السوق',
    navLogin:'دخول',
    navRegister:'تسجيل',
    navAddAd:'+ أضف إعلان',
    navMyAds:'إعلاناتي',
    searchPlaceholder:'ابحث عن ساعة...',
    themeLabel:'الوضع الليلي',
    browseByBrand:'تصفح حسب الماركة',
    latestAds:'آخر الإعلانات',
    howTitle:'كيف يعمل السوق',
    howSub:'ثلاث خطوات <em>بسيطة</em>',
    step1t:'سجّل حسابك', step1s:'أنشئ حساباً بالاسم والواتساب في ثوانٍ',
    step2t:'أضف إعلانك', step2s:'ارفع صور ساعتك وحدد السعر والتفاصيل',
    step3t:'تواصل مباشرة', step3s:'المشترون يتواصلون معك عبر الواتساب مباشرة',
    viewAll:'عرض الكل',
    postTitle:'أضف <em>إعلانك</em>',
    postSub:'أضف تفاصيل ساعتك وسيظهر الإعلان فوراً في السوق',
    available:'متاحة', sold:'مُباعة', newBadge:'جديد',
    whatsapp:'واتساب', enquire:'استفسار', negotiable:'قابل',
    brandLabel:'الماركة', modelLabel:'الموديل', condLabel:'الحالة',
    priceLabel:'السعر (AED)', waLabel:'رقم الواتساب للتواصل',
    publishBtn:'نشر الإعلان الآن',
    successTitle:'نُشر الإعلان!',
    successText:'ساعتك الآن مرئية في سوق Aurex Movement. المشترون سيتواصلون معك مباشرة عبر الواتساب.',
    myAdsTitle:'إعلاناتي <em>الخاصة</em>',
    loginTab:'دخول', registerTab:'تسجيل جديد',
    loginBtn:'دخول', registerBtn:'إنشاء الحساب',
    markSoldBtn:'مُباع', deleteBtn:'حذف', relistBtn:'إعادة نشر',
    backBtn:'العودة', contactWa:'تواصل عبر الواتساب',
    filterBrand:'الماركة', filterCond:'الحالة', filterSet:'البوكس والأوراق',
    filterPrice:'نطاق السعر (AED)', resetFilter:'إعادة ضبط الفلاتر',
    sortNewest:'الأحدث', sortPriceAsc:'السعر: الأقل', sortPriceDesc:'السعر: الأعلى',
    noResults:'لا توجد نتائج', noResultsSub:'جرب تغيير الفلاتر',
    emptyMyAds:'لا توجد إعلانات بعد', emptyMyAdsSub:'أضف ساعتك الأولى الآن',
    addFirst:'أضف إعلاناً',
    specsBrand:'الماركة', specsModel:'الموديل', specsRef:'رقم المرجع',
    specsYear:'سنة الإنتاج', specsCond:'الحالة', specsSet:'البوكس والأوراق',
    specsDial:'لون الديال', specsCity:'الإمارة',
    sellerLabel:'بائع موثق', priceFixed:'السعر ثابت', priceNeg:'قابل للتفاوض',
    termsText:'أؤكد أن المعلومات المدخلة صحيحة وأن الساعة أصيلة 100%. أوافق على قواعد Aurex Movement للبيع والشراء.',
    emptyTitle:'لا توجد إعلانات بعد',
    emptySubTitle:'كن أول من ينشر ساعته!',
    emptyBtn:'أضف إعلانك الآن',
    listingsPageTitle:'سوق <em>الساعات</em>',
    listingsAddBtn:'+ أضف إعلانك',
    myadsNewBtn:'+ إعلان جديد',
    allListings:'جميع الإعلانات',
    postPreviewTitle:'◈ معاينة الإعلان',
    footerTerms:'الشروط والأحكام',
    footerPrivacy:'سياسة الخصوصية',
    acctModalLogout:'تسجيل الخروج',
    dir:'rtl', lang:'ar',
  },
  en:{
    siteName:'Aurex Movement',
    heroBadge:'UAE & GCC · Luxury Watch Marketplace',
    heroH1:'Luxury <em>Watch</em><br>Marketplace',
    heroSub:'The exclusive platform to buy and sell authentic luxury watches in the UAE and GCC.',
    heroDivider:'Buy · Sell · Direct Contact',
    heroBrowse:'Browse Listings',
    heroPost:'+ List Your Watch',
    statLabel:'Active Listings',
    navMarket:'Market',
    navLogin:'Login',
    navRegister:'Register',
    navAddAd:'+ Add Listing',
    navMyAds:'My Ads',
    searchPlaceholder:'Search for a watch...',
    themeLabel:'Dark Mode',
    browseByBrand:'Browse by Brand',
    latestAds:'Latest Listings',
    howTitle:'How It Works',
    howSub:'Three <em>simple</em> steps',
    step1t:'Create Account', step1s:'Sign up with your name and WhatsApp in seconds',
    step2t:'Add Your Listing', step2s:'Upload photos, set your price and details',
    step3t:'Connect Directly', step3s:'Buyers contact you directly via WhatsApp',
    viewAll:'View All',
    postTitle:'Add Your <em>Listing</em>',
    postSub:'Add your watch details and your listing will appear in the market immediately',
    available:'Available', sold:'Sold', newBadge:'New',
    whatsapp:'WhatsApp', enquire:'Enquire', negotiable:'OBO',
    brandLabel:'Brand', modelLabel:'Model', condLabel:'Condition',
    priceLabel:'Price (AED)', waLabel:'WhatsApp Number for Contact',
    publishBtn:'Publish Listing Now',
    successTitle:'Listing Published!',
    successText:'Your watch is now live on the Aurex Movement marketplace. Buyers will contact you directly via WhatsApp.',
    myAdsTitle:'My <em>Listings</em>',
    loginTab:'Login', registerTab:'New Account',
    loginBtn:'Login', registerBtn:'Create Account',
    markSoldBtn:'Mark Sold', deleteBtn:'Delete', relistBtn:'Relist',
    backBtn:'Back', contactWa:'Contact on WhatsApp',
    filterBrand:'Brand', filterCond:'Condition', filterSet:'Box & Papers',
    filterPrice:'Price Range (AED)', resetFilter:'Reset Filters',
    sortNewest:'Newest', sortPriceAsc:'Price: Low to High', sortPriceDesc:'Price: High to Low',
    noResults:'No Results Found', noResultsSub:'Try adjusting your filters',
    emptyMyAds:'No listings yet', emptyMyAdsSub:'Add your first watch now',
    addFirst:'Add a Listing',
    specsBrand:'Brand', specsModel:'Model', specsRef:'Reference No.',
    specsYear:'Year', specsCond:'Condition', specsSet:'Box & Papers',
    specsDial:'Dial Color', specsCity:'Emirate',
    sellerLabel:'Verified Seller', priceFixed:'Fixed Price', priceNeg:'Price Negotiable',
    termsText:'I confirm that all information is accurate and the watch is 100% authentic. I agree to Aurex Movement\'s terms.',
    emptyTitle:'No listings yet',
    emptySubTitle:'Be the first to list your watch!',
    emptyBtn:'Add Your Listing Now',
    listingsPageTitle:'Watch <em>Market</em>',
    listingsAddBtn:'+ Add Listing',
    myadsNewBtn:'+ New Listing',
    allListings:'All Listings',
    postPreviewTitle:'◈ Listing Preview',
    footerTerms:'Terms & Conditions',
    footerPrivacy:'Privacy Policy',
    acctModalLogout:'Log Out',
    dir:'ltr', lang:'en',
  }
};

let currentLang = localStorage.getItem('aurex_lang')||'ar';
let currentTheme = localStorage.getItem('aurex_theme')||'dark';

function applyTheme(theme){
  document.documentElement.setAttribute('data-theme', theme==='light'?'light':'dark');
  document.getElementById('themeToggle').checked = (theme==='dark');
  document.getElementById('themeLabel').textContent = T[currentLang].themeLabel;
  currentTheme = theme;
  localStorage.setItem('aurex_theme', theme);
}

function toggleTheme(isDark){
  applyTheme(isDark?'dark':'light');
}

function setLang(lang){
  currentLang = lang;
  localStorage.setItem('aurex_lang', lang);
  document.documentElement.setAttribute('lang', lang);
  document.documentElement.setAttribute('dir', T[lang].dir);
  document.querySelectorAll('input,select,textarea,button').forEach(el=>{ el.style.fontFamily = lang==='ar'?"'Tajawal',sans-serif":"'Montserrat',sans-serif"; });
  document.body.style.fontFamily = lang==='ar'?"'Tajawal',sans-serif":"'Montserrat',sans-serif";
  document.getElementById('pillAr').classList.toggle('active', lang==='ar');
  document.getElementById('pillEn').classList.toggle('active', lang==='en');
  applyTranslations();
}

function t(key){ return T[currentLang][key]||T['ar'][key]||key; }

function applyTranslations(){
  const L = T[currentLang];
  // Back buttons
  safeText('detailBackTxt', L.backBtn);
  // Nav
  safeText('navMarketBtn', L.navMarket);
  safeText('navLoginBtn', L.navLogin);
  safeText('navRegisterBtn', L.navRegister);
  safeText('navAddAdBtn', L.navAddAd);
  safeText('navMyAdsBtn', L.navMyAds);
  const si = document.getElementById('globalSearch');
  if(si) si.placeholder = L.searchPlaceholder;
  // Hero
  safeHTML('heroBadgeEl', L.heroBadge);
  safeHTML('heroH1El', L.heroH1);
  safeText('heroSubEl', L.heroSub);
  safeText('heroDividerEl', L.heroDivider);
  safeText('heroBrowseBtn', L.heroBrowse);
  safeText('heroPostBtn', L.heroPost);
  safeText('heroStatLabel', L.statLabel);
  safeText('howTitleEl', L.howTitle);
  safeHTML('howSubEl', L.howSub);
  safeText('step1Title', L.step1t); safeText('step1Sub', L.step1s);
  safeText('step2Title', L.step2t); safeText('step2Sub', L.step2s);
  safeText('step3Title', L.step3t); safeText('step3Sub', L.step3s);
  safeText('viewAllBtn', L.viewAll);
  safeHTML('postTitleEl', L.postTitle);
  safeText('postSubEl', L.postSub);
  safeHTML('myAdsTitleEl', L.myAdsTitle);
  safeText('publishBtnEl', L.publishBtn);
  safeText('themeLabel', L.themeLabel);
  safeHTML('browseByBrandEl', L.browseByBrand);
  safeHTML('latestAdsEl', L.latestAds);
  safeHTML('latestHeadingEl', currentLang==='ar'?'أحدث <em style="color:var(--gold);font-style:italic">الساعات</em>':'Latest <em style="color:var(--gold);font-style:italic">Watches</em>');
  // Sidebar filter labels
  safeText('filterBrandLabel', L.filterBrand);
  safeText('filterCondLabel', L.filterCond);
  safeText('filterSetLabel', L.filterSet);
  safeText('filterPriceLabel', L.filterPrice);
  safeText('resetFilterBtn', L.resetFilter);
  // Sort
  const sort = document.getElementById('sortSel');
  if(sort){ sort.options[0].text=L.sortNewest; sort.options[1].text=L.sortPriceAsc; sort.options[2].text=L.sortPriceDesc; }
  // Auth modal
  safeText('tabLogin', L.loginTab);
  safeText('tabRegister', L.registerTab);
  safeText('loginBtnEl', L.loginBtn);
  safeText('registerBtnEl', L.registerBtn);
  // Terms
  safeText('termsLabelEl', L.termsText);
  safeText('emptyTitle', L.emptyTitle);
  safeText('emptySubTitle', L.emptySubTitle);
  safeText('emptyBtn', L.emptyBtn);
  safeHTML('listingsPageTitle', L.listingsPageTitle);
  safeText('listingsAddBtn', L.listingsAddBtn);
  safeText('myadsNewBtn', L.myadsNewBtn);
  safeText('listingsCount', L.allListings);

  // Translate filter dropdown options
  const fBrand = document.getElementById('fBrand');
  if(fBrand){ 
    fBrand.options[0].text = currentLang==='ar'?'الكل':'All';
    // translate second to last option (أخرى)
    const lastOpt = fBrand.options[fBrand.options.length-1];
    if(lastOpt) lastOpt.text = currentLang==='ar'?'أخرى':'Other';
  }

  // Translate post brand select
  const pBrand = document.getElementById('pBrand');
  if(pBrand){ 
    pBrand.options[0].text = currentLang==='ar'?'اختر الماركة':'Select Brand';
    const lastPBrand = pBrand.options[pBrand.options.length-1];
    if(lastPBrand) lastPBrand.text = currentLang==='ar'?'أخرى':'Other';
  }

  const fCond = document.getElementById('fCond');
  if(fCond){
    const condOpts = currentLang==='ar'
      ?['الكل','جديدة','شبه جديدة','ممتازة','جيدة']
      :['All','New','Like New','Excellent','Good'];
    Array.from(fCond.options).forEach((o,i)=>{ if(condOpts[i]) o.text=condOpts[i]; });
  }

  const fSet = document.getElementById('fSet');
  if(fSet){
    const setOpts = currentLang==='ar'
      ?['الكل','Full Set','بدون بوكس','بوكس فقط']
      :['All','Full Set','No Box','Box Only'];
    Array.from(fSet.options).forEach((o,i)=>{ if(setOpts[i]) o.text=setOpts[i]; });
  }

  // Translate price placeholders
  const fMin = document.getElementById('fPriceMin');
  const fMax = document.getElementById('fPriceMax');
  if(fMin) fMin.placeholder = currentLang==='ar'?'من':'From';
  if(fMax) fMax.placeholder = currentLang==='ar'?'إلى':'To';

  // Translate listings empty state
  const lEmpty = document.getElementById('listingsEmpty');
  if(lEmpty){
    const p1 = lEmpty.querySelector('p:first-of-type');
    const p2 = lEmpty.querySelector('p:last-of-type');
    if(p1) p1.textContent = currentLang==='ar'?'لا توجد نتائج':'No Results Found';
    if(p2) p2.textContent = currentLang==='ar'?'جرب تغيير الفلاتر':'Try adjusting your filters';
  }

  const pCond = document.getElementById('pCond');
  if(pCond){
    const opts = currentLang==='ar'
      ?['اختر الحالة','جديدة','شبه جديدة','ممتازة','جيدة']
      :['Select Condition','New','Like New','Excellent','Good'];
    Array.from(pCond.options).forEach((o,i)=>{ if(opts[i]) o.text=opts[i]; });
  }

  const pSet = document.getElementById('pSet');
  if(pSet){
    const opts = currentLang==='ar'
      ?['اختر','Full Set (بوكس + أوراق)','بوكس فقط','أوراق فقط','بدون بوكس أو أوراق']
      :['Select','Full Set (Box + Papers)','Box Only','Papers Only','No Box or Papers'];
    Array.from(pSet.options).forEach((o,i)=>{ if(opts[i]) o.text=opts[i]; });
  }

  const pNeg = document.getElementById('pNeg');
  if(pNeg){
    pNeg.options[0].text = currentLang==='ar'?'السعر ثابت':'Fixed Price';
    pNeg.options[1].text = currentLang==='ar'?'قابل للتفاوض':'Negotiable';
  }

  const pCity = document.getElementById('pCity');
  if(pCity){
    const opts = currentLang==='ar'
      ?['اختر الإمارة','دبي','أبوظبي','الشارقة','عجمان','رأس الخيمة','الفجيرة','أم القيوين']
      :['Select Emirate','Dubai','Abu Dhabi','Sharjah','Ajman','Ras Al Khaimah','Fujairah','Umm Al Quwain'];
    Array.from(pCity.options).forEach((o,i)=>{ if(opts[i]) o.text=opts[i]; });
  }

  // Translate auth modal labels
  safeText('loginEmailLabel', currentLang==='ar'?'الإيميل':'Email');
  safeText('forgotPassBtn', currentLang==='ar'?'نسيت كلمة المرور؟':'Forgot password?');
  safeText('switchToRegister', currentLang==='ar'?'سجّل الآن':'Register now');

  // Translate dropdown menu items
  safeText('dropMenuMyAds', currentLang==='ar'?'إعلاناتي':'My Listings');
  safeText('dropMenuFav', currentLang==='ar'?'المفضلة':'Favorites');
  safeHTML('favTitleEl', currentLang==='ar'?'المفضلة <em>الخاصة</em>':'My <em>Favorites</em>');
  safeText('favBrowseBtn', currentLang==='ar'?'تصفح السوق':'Browse Market');
  safeText('dropMenuAccount', currentLang==='ar'?'معلومات الحساب':'Account Info');
  safeText('dropMenuSettings', currentLang==='ar'?'ملفي الشخصي':'My Profile');
  safeText('dropMenuLogout', currentLang==='ar'?'تسجيل الخروج':'Log Out');

  // Auth modal full translation
  safeText('modalTitle', currentLang==='ar'?'مرحباً بك':'Welcome');
  safeText('modalSub', currentLang==='ar'?'سجّل دخولك للبيع والشراء':'Sign in to buy and sell');
  safeText('tabLogin', currentLang==='ar'?'دخول':'Login');
  safeText('tabRegister', currentLang==='ar'?'تسجيل جديد':'New Account');
  safeText('loginEmailLabel', currentLang==='ar'?'الإيميل':'Email');
  safeText('loginPassLabel', currentLang==='ar'?'كلمة المرور':'Password');
  safeText('loginBtnEl', currentLang==='ar'?'دخول':'Login');
  safeText('forgotPassBtn', currentLang==='ar'?'نسيت كلمة المرور؟':'Forgot password?');
  safeHTML('loginSwitchText', currentLang==='ar'
    ?'ليس لديك حساب؟ <a onclick="switchTab(\'register\')" id="switchToRegister">سجّل الآن</a>'
    :'Don\'t have an account? <a onclick="switchTab(\'register\')" id="switchToRegister">Register</a>');
  safeText('regNameLabel', currentLang==='ar'?'الاسم':'Name');
  safeText('regEmailLabel', currentLang==='ar'?'الإيميل':'Email');
  safeText('regWALabel', currentLang==='ar'?'رقم الواتساب':'WhatsApp Number');
  safeText('regWAHint', currentLang==='ar'?'سيظهر هذا الرقم للمشترين':'This number will be visible to buyers');
  safeText('regPassLabel', currentLang==='ar'?'كلمة المرور':'Password');
  safeText('registerBtnEl', currentLang==='ar'?'إنشاء الحساب':'Create Account');
  safeHTML('regTermsNote', currentLang==='ar'
    ?'بإنشاء حسابك، أنت توافق على <a onclick="closeModal();showView(\'terms\')" style="color:var(--gold);cursor:pointer;text-decoration:underline">الشروط والأحكام</a>'
    :'By creating an account, you agree to our <a onclick="closeModal();showView(\'terms\')" style="color:var(--gold);cursor:pointer;text-decoration:underline">Terms & Conditions</a>');
  safeHTML('registerSwitchText', currentLang==='ar'
    ?'لديك حساب؟ <a onclick="switchTab(\'login\')" id="switchToLogin">دخول</a>'
    :'Already have an account? <a onclick="switchTab(\'login\')" id="switchToLogin">Login</a>');

  // Register input placeholders
  const rn = document.getElementById('regName'); if(rn) rn.placeholder = currentLang==='ar'?'اسمك الكامل':'Full name';
  const rp = document.getElementById('regPass'); if(rp) rp.placeholder = currentLang==='ar'?'6 أحرف على الأقل':'At least 6 characters';

  // Hero stats
  safeText('heroStatGCC', currentLang==='ar'?'الإمارات والخليج':'UAE & GCC');
  safeText('heroStatDirect', currentLang==='ar'?'تواصل مباشر':'Direct Contact');

  // Brands section
  safeHTML('brandsTitle', currentLang==='ar'?'الماركات <em style="color:var(--gold);font-style:italic">المتاحة</em>':'Available <em style="color:var(--gold);font-style:italic">Brands</em>');
  const brandAll = document.getElementById('brandPillAll');
  if(brandAll){
    const nm = brandAll.querySelector('.brand-card-name');
    const sb2 = brandAll.querySelector('.brand-card-sub');
    if(nm) nm.textContent = currentLang==='ar'?'عرض الكل':'View All';
    if(sb2) sb2.textContent = currentLang==='ar'?'جميع الماركات':'All Brands';
  }
  // Localize brand-card location subtitles (skip the View All card handled above)
  document.querySelectorAll('.brand-card-sub[data-ar]').forEach(el=>{
    const txt = currentLang==='ar' ? el.getAttribute('data-ar') : el.getAttribute('data-en');
    if(txt) el.textContent = txt;
  });

  // Contact translations
  safeText('contactFormTitle', currentLang==='ar'?'تواصل معنا':'Contact Us');
  safeText('contactBlurb', currentLang==='ar'?'عندك سؤال أو ملاحظة؟ راسلنا مباشرة وبنرد عليك بأسرع وقت':'Have a question or feedback? Email us directly and we\'ll get back to you soon');
  const ceb = document.getElementById('contactEmailBtn');
  if(ceb){
    const icon = ceb.querySelector('svg').outerHTML;
    ceb.innerHTML = icon + (currentLang==='ar'?'راسلنا عبر الإيميل':'Email Us');
  }

  // Post form — section titles
  safeText('postSecImages', currentLang==='ar'?'الصور':'Photos');
  safeText('postSecDetails', currentLang==='ar'?'تفاصيل الساعة':'Watch Details');
  safeText('postSecPrice', currentLang==='ar'?'السعر والتواصل':'Price & Contact');

  // Post form — image notes
  safeText('imgNote', currentLang==='ar'?'JPG, PNG حتى 10MB لكل صورة':'JPG, PNG up to 10MB per image');
  safeText('imgMainNote', currentLang==='ar'?'◈ الصورة الأولى ستظهر كصورة رئيسية في الإعلان':'◈ The first photo will be the main image of the listing');

  // Post form — image slot labels
  const slot0span = document.querySelector('#slot0 span:last-child');
  if(slot0span && !slotImages[0]) slot0span.textContent = currentLang==='ar'?'الصورة الرئيسية':'Main Photo';
  [1,2,3].forEach(i=>{ const s=document.querySelector('#slot'+i+' span:last-child'); if(s && !slotImages[i]) s.textContent = currentLang==='ar'?'إضافة':'Add'; });

  // Post form — field labels (with required asterisk)
  const req = '<span>*</span>';
  safeHTML('lblBrand', (currentLang==='ar'?'الماركة ':'Brand ')+req);
  safeHTML('lblModel', (currentLang==='ar'?'الموديل ':'Model ')+req);
  safeText('lblRef', currentLang==='ar'?'رقم المرجع (Ref.)':'Reference No. (Ref.)');
  safeText('lblYear', currentLang==='ar'?'سنة الإنتاج':'Year');
  safeText('lblDial', currentLang==='ar'?'لون الديال':'Dial Color');
  safeHTML('lblCond', (currentLang==='ar'?'الحالة ':'Condition ')+req);
  safeText('lblSet', currentLang==='ar'?'البوكس والأوراق':'Box & Papers');
  safeText('lblDesc', currentLang==='ar'?'وصف الساعة':'Watch Description');
  safeHTML('lblPrice', (currentLang==='ar'?'السعر (AED) ':'Price (AED) ')+req);
  safeText('lblNeg', currentLang==='ar'?'قابلية التفاوض':'Negotiable');
  safeHTML('lblWA', (currentLang==='ar'?'رقم الواتساب للتواصل ':'WhatsApp Number ')+req);
  safeText('hintWA', currentLang==='ar'?'سيظهر هذا الرقم للمشترين للتواصل معك مباشرة':'This number will be shown to buyers to contact you directly');
  safeText('lblCity', currentLang==='ar'?'الإمارة':'Emirate');

  // Post form — input placeholders
  const ph = (id,ar,en)=>{ const el=document.getElementById(id); if(el) el.placeholder = currentLang==='ar'?ar:en; };
  ph('pModel','مثال: Submariner، Nautilus...','e.g. Submariner, Nautilus...');
  ph('pRef','مثال: 116610LN','e.g. 116610LN');
  ph('pYear','مثال: 2021','e.g. 2021');
  ph('pDial','مثال: أسود، أزرق...','e.g. Black, Blue...');
  ph('pDesc','اكتب أي تفاصيل إضافية تريد أن يعرفها المشتري...','Add any extra details you want buyers to know...');
  ph('pPrice','مثال: 45000','e.g. 45000');

  // Post form — pSet box/papers options
  const pSetEl = document.getElementById('pSet');
  if(pSetEl){
    const o = currentLang==='ar'
      ?['اختر','Full Set (بوكس + أوراق)','بوكس فقط','أوراق فقط','بدون بوكس أو أوراق']
      :['Select','Full Set (Box + Papers)','Box Only','Papers Only','No Box or Papers'];
    Array.from(pSetEl.options).forEach((opt,i)=>{ if(o[i]) opt.text=o[i]; });
  }

  // Post form — publish helper note
  safeText('publishHint', currentLang==='ar'?'سيظهر إعلانك فوراً في السوق بعد النشر':'Your listing will appear in the market immediately after publishing');

  // Success page (after publishing)
  safeText('successTitleEl', currentLang==='ar'?'نُشر الإعلان!':'Listing Published!');
  safeText('successTextEl', currentLang==='ar'?'ساعتك الآن مرئية في سوق Aurex Movement. المشترون سيتواصلون معك مباشرة عبر الواتساب.':'Your watch is now live on the Aurex Movement marketplace. Buyers will contact you directly via WhatsApp.');
  safeText('successBrowseBtn', currentLang==='ar'?'تصفح السوق':'Browse Market');
  safeText('successMyAdsBtn', currentLang==='ar'?'إعلاناتي':'My Listings');

  // Terms page
  safeText('termsBackTxt', currentLang==='ar'?'العودة':'Back');
  safeText('termsPageTitle', currentLang==='ar'?'الشروط والأحكام':'Terms & Conditions');
  safeText('termsUpdated', currentLang==='ar'?'آخر تحديث: يونيو 2026':'Last updated: June 2026');
  renderTerms();

  // Footer links
  safeText('footerTermsLink', L.footerTerms);
  safeText('footerPrivacyLink', L.footerPrivacy);

  // Post preview title
  safeText('postPreviewTitle', L.postPreviewTitle);

  // Account modal logout
  safeText('acctModalLogout', L.acctModalLogout);

  // Re-render grids to pick up new labels
  renderHomeGrid();
  if(currentView==='listings') filterListings();
  if(currentView==='myads') renderMyAds();
}

function renderTerms(){
  const body = document.getElementById('termsBody');
  if(!body) return;
  const ar = [
    ['طبيعة المنصة','Aurex Movement منصة إعلانات تتيح لأصحاب الساعات عرض ساعاتهم للبيع والتواصل مع المشترين مباشرةً. نحن وسيط عرض فقط، ولسنا طرفاً في أي عملية بيع أو شراء، ولا نملك أو نبيع أو نضمن أي ساعة معروضة على المنصة.'],
    ['مسؤولية البائع','البائع وحده مسؤول عن صحة المعلومات والصور وأصالة الساعة وحالتها وسعرها. بنشر أي إعلان، يقرّ البائع أن الساعة أصلية وأن جميع التفاصيل صحيحة، وأنه يملك الحق في بيعها.'],
    ['الصفقات بين الطرفين','جميع المفاوضات والمدفوعات والتسليم تتم مباشرةً بين البائع والمشتري خارج المنصة. Aurex Movement لا تتدخل في الدفع ولا تتحمّل أي مسؤولية عن الأموال أو السلع أو أي نزاع ينشأ بين الطرفين.'],
    ['التحقق والاحتيال','ننصح المشترين بفحص الساعة والتحقق من أصالتها قبل الدفع. نحتفظ بحق حذف أي إعلان مخالف أو مشبوه أو كاذب دون إشعار مسبق.'],
    ['المحتوى الممنوع','يُمنع نشر إعلانات لساعات مقلّدة أو مسروقة أو غير قانونية، أو أي محتوى مخالف للأنظمة في دولة الإمارات. أي مخالفة قد تؤدي لحذف الحساب.'],
    ['حدود المسؤولية','تُقدَّم المنصة "كما هي". لا نضمن استمرار الخدمة دون انقطاع، ولا نتحمّل أي خسائر مباشرة أو غير مباشرة ناتجة عن استخدام الموقع أو التعامل مع المستخدمين الآخرين.'],
    ['الخصوصية','نجمع فقط البيانات اللازمة لتشغيل المنصة (الاسم، الإيميل، رقم الواتساب). رقم الواتساب يظهر للمشترين بغرض التواصل. لا نبيع بياناتك لأي طرف ثالث.'],
    ['التواصل','لأي استفسار أو بلاغ عن إعلان مخالف، راسلنا على support@aurexmovement.com']
  ];
  const en = [
    ['Nature of the Platform','Aurex Movement is a listings platform that lets watch owners showcase their watches for sale and connect with buyers directly. We are a listing intermediary only — not a party to any sale, and we do not own, sell, or guarantee any watch listed on the platform.'],
    ['Seller Responsibility','The seller is solely responsible for the accuracy of the information, photos, authenticity, condition, and price of the watch. By posting a listing, the seller confirms the watch is authentic, all details are correct, and they have the right to sell it.'],
    ['Transactions Between Parties','All negotiations, payments, and delivery happen directly between buyer and seller, off the platform. Aurex Movement is not involved in payment and bears no responsibility for funds, goods, or any dispute arising between the parties.'],
    ['Verification & Fraud','We advise buyers to inspect the watch and verify its authenticity before paying. We reserve the right to remove any violating, suspicious, or fraudulent listing without prior notice.'],
    ['Prohibited Content','Listings for counterfeit, stolen, or illegal watches — or any content that violates UAE laws — are prohibited. Any violation may result in account removal.'],
    ['Limitation of Liability','The platform is provided "as is". We do not guarantee uninterrupted service, and we are not liable for any direct or indirect losses arising from using the site or dealing with other users.'],
    ['Privacy','We collect only the data needed to run the platform (name, email, WhatsApp number). Your WhatsApp number is shown to buyers for contact purposes. We do not sell your data to any third party.'],
    ['Contact','For any inquiry or to report a violating listing, email us at support@aurexmovement.com']
  ];
  const items = currentLang==='ar'?ar:en;
  body.innerHTML = items.map((s,i)=>`
    <div style="margin-bottom:1.8rem">
      <h3 style="font-family:var(--serif);font-size:1.25rem;color:var(--gold);font-weight:400;margin-bottom:.5rem">${i+1}. ${s[0]}</h3>
      <p style="font-size:.88rem;color:var(--grey);line-height:1.9">${s[1]}</p>
    </div>
  `).join('');
}

function safeText(id, val){ const el=document.getElementById(id); if(el) el.textContent=val; }
function safeHTML(id, val){ const el=document.getElementById(id); if(el) el.innerHTML=val; }

function openAccountInfo(){
  if(!currentUser) return;
  const myAds = listings.filter(l=>l.userId===currentUser.id).length;
  document.getElementById('acctNameVal').textContent = currentUser.name;
  document.getElementById('acctWaVal').textContent = '+971 '+currentUser.wa;
  document.getElementById('acctAdsVal').textContent = myAds + (currentLang==='ar'?' إعلان':' listing(s)');
  document.getElementById('acctTitle').textContent = currentLang==='ar'?'معلومات الحساب':'Account Info';
  document.getElementById('acctNameLabel').textContent = currentLang==='ar'?'الاسم':'Name';
  document.getElementById('acctWaLabel').textContent = currentLang==='ar'?'رقم الواتساب':'WhatsApp';
  document.getElementById('acctAdsLabel').textContent = currentLang==='ar'?'إعلاناتي':'My Listings';
  document.getElementById('accountModal').classList.add('open');
}

// Close dropdowns on outside click - unified handler
document.addEventListener('click', e=>{
  const wrap = document.getElementById('avatarWrap');
  if(wrap && !wrap.contains(e.target)){
    closeAvatarMenu();
  }
  const panel = document.getElementById('settingsPanel');
  const fab = document.getElementById('settingsFab');
  if(panel && fab && panel.classList.contains('open') && !panel.contains(e.target) && !fab.contains(e.target)){
    panel.classList.remove('open');
  }
});

// ════════════════════════════════════════════════
// START
// ════════════════════════════════════════════════
// Browser back/forward: open watch from hash, or return to listings
window.addEventListener('popstate', async ()=>{
  const matched = await handleHashRoute();
  if(!matched && currentView==='detail'){
    showView('listings');
  }
});

init();
